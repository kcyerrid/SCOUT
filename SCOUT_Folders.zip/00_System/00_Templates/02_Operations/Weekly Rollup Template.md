---
entity_type: weekly_rollup
week_of: ""
week_number: ""
analyst_or_team: ""
weekly_soul_score: 9
weekly_career_score: 6
weekly_relationships_score: 8
weekly_health_score: 7
weekly_personal_growth_score: 3
weekly_fun_score: 8
weekly_social_score: 6
weekly_finance_score: 8
weekly_energy_score: 9
weekly_cynicism_score: 5
weekly_productivity_score: 8
operational_focus_areas: []  
key_incidents: []
key_investigations: []
alerts_reviewed: 0
incidents_opened: 0
incidents_closed: 0
investigations_opened: 0
investigations_closed: 0
response_actions_taken: 0
observations_logged: 0
notable_ttp_activity: []
notable_iocs: []
notable_actors: []
sla_performance: ""
mttd_summary: ""
mttr_summary: ""
alert_volume_trend:
  - increasing
  - decreasing
  - stable
team_health: ""
tags: []
created:
updated:
journal: Journal Weekly
journal_date: 
journal_start_date: 
journal_end_date: 
banner: 99_Attachments/SCOUT_Obsidian_Banner.png
banner-display: contain
banner-repeat: false
banner-height: 100
content-start: 101
---
## Week
<%*
var start_of_week = moment(tp.file.title, "YYYY-[W]WW").startOf("week");
var days_in_week = 7;

// Admonition header
tR += "> [!capacities-prop]- Pictures of the Day (Oldest → Newest)\n";

for (var i = 0; i < days_in_week; i++) {
  var d = moment(start_of_week).add(i, "days").format("YYYY-MM-DD");

  // Find the daily note by title (e.g., "2025-01-06")
  var tfile = tp.file.find_tfile(d);
  if (!tfile) {
    continue; // no daily note for this date
  }

  // Pull frontmatter "picture_of_the_day"
  var cache = tp.app.metadataCache.getFileCache(tfile);
  var fm = cache ? cache.frontmatter : null;
  var pic = fm ? fm.picture_of_the_day : null;
  if (!pic) {
    continue;
  }
  // Normalize wikilinks if stored as [[...]] or ![[...]]
  pic = String(pic).trim();
  if (pic.startsWith("![[") && pic.endsWith("]]")) {
    pic = pic.slice(3, -2).trim();
  } else if (pic.startsWith("[[") && pic.endsWith("]]")) {
    pic = pic.slice(2, -2).trim();
  }
  // Strip any existing size suffix
  if (pic.includes("|")) {
    pic = pic.split("|")[0].trim();
  }
  if (!pic) {
    continue;
  }
  // Render as thumbnail (150px)
  tR += "> ![[" + pic + "|150]]\n";
}
%>

<%*
var end_of_week = moment(start_of_week).add(6, "days");
var weekStart = start_of_week.format("YYYY-MM-DD");
var weekEnd   = end_of_week.format("YYYY-MM-DD");
%>

> [!calendar]- Burnout Monitoring
>```dataviewjs
>const start = dv.date("<% weekStart %>");
>const end = dv.date("<% weekEnd %>");
>const dailyPath = "10_Operations/09_Journals/01_Daily";
>
>const rows = dv
>  .pages(`"${dailyPath}"`)
>  .where((p) => p.file?.day && p.file.day >= start && p.file.day <= end)
>  .sort((p) => p.file.day, "asc")
>  .map((p) => ({
>    date: p.file.day,
>    energy: Number(p.energy_rating),
>    cynicism: Number(p.cynicism_rating),
>    productivity: Number(p.productivity_rating),
>  }))
>  .array();
>
>const labels = rows.map((r) => r.date.toFormat("MM-dd"));
>
>const buildChart = (title, values, color) => {
>  const chartData = {
>    type: "line",
>    data: {
>      labels,
>      datasets: [
>        {
>          label: title,
>          data: values,
>          fill: false,
>          backgroundColor: "rgba(0,0,0,0)",
>          borderColor: color,
>          tension: 0.3,
>          pointRadius: 2,
>        },
>      ],
>    },
>    options: {
>      plugins: {
>        legend: { position: "bottom" },
>      },
>      scales: {
>        y: { min: 0, max: 10, ticks: { stepSize: 1, color: "black" }, grid: { color: "rgba(150,150,150,0.3)" } },
>        x: { ticks: { color: "black" }, grid: { color: "rgba(150,150,150,0.1)" } },
>      },
>    },
>  };
>  const container = this.container.createDiv({ cls: "weekly-metric-chart" });
>  container.style.height = "300px";
>  container.style.marginTop = "24px";
>  container.style.marginBottom = "24px";
>  window.renderChart(chartData, container);
>};
>
>if (rows.length === 0) {
>  dv.paragraph("No daily notes found for this week.");
>} else {
>  buildChart("Energy", rows.map((r) => r.energy), "rgba(3, 169, 244, 0.9)");
>  buildChart("Cynicism", rows.map((r) => r.cynicism), "rgba(233, 30, 99, 0.9)");
>  buildChart("Productivity", rows.map((r) => r.productivity), "rgba(76, 175, 80, 0.9)");
>}
>```

> [!highlight]- Highlights!
> ```dataview
> TABLE
>  file.day AS "Date",
>  file.tags AS "Tags",
>  aliases AS "Aliases"
>  FROM "10_Operations/09_Journals/01_Daily"
>  WHERE aliases != null
>  AND length(aliases) >= 1
>  AND file.day >= date("<% weekStart %>")
>  AND file.day <= date("<% weekEnd %>")
>  SORT file.day ASC

## Weekly Status Report Items
<!-- Tag taxonomy mirrored from Daily Journal Template:
- #report/weekly
- #milestone/accomplishment
- #milestone/incident
- #milestone/impact
-->
```dataviewjs
const start = dv.date("<% weekStart %>");
const end = dv.date("<% weekEnd %>");
const dailyPath = "10_Operations/09_Journals/01_Daily";
const tagList = [
  "#report/weekly",
  "#milestone/accomplishment",
  "#milestone/incident",
  "#milestone/impact"
];
const tagSet = new Set(tagList);
const tagRegex = /(#[A-Za-z0-9/_-]+)/g;

const items = [];
const counts = {};
for (const tag of tagList) {
  counts[tag] = 0;
}

const pages = dv
  .pages(`"${dailyPath}"`)
  .where((p) => p.file?.day >= start && p.file?.day <= end)
  .sort((p) => p.file.day, "asc");

for (const page of pages) {
  const content = await dv.io.load(page.file.path);
  const lines = content.split("\n");
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line.includes("#")) continue;
    const matches = line.match(tagRegex) ?? [];
    const matchedTags = matches.filter((tag) => tagSet.has(tag));
    if (matchedTags.length === 0) continue;
    for (const tag of matchedTags) {
      counts[tag] += 1;
    }
    items.push([page.file.link, line, matchedTags.join(", ")]);
  }
}

if (items.length === 0) {
  dv.paragraph("No tagged status items found for this week.");
} else {
  dv.table(["Daily Note", "Entry", "Tags"], items);
}
```

### Weekly Status Tag Summary
```dataviewjs
const tagList = [
  "#report/weekly",
  "#milestone/accomplishment",
  "#milestone/incident",
  "#milestone/impact"
];
const tagSet = new Set(tagList);
const tagRegex = /(#[A-Za-z0-9/_-]+)/g;
const start = dv.date("<% weekStart %>");
const end = dv.date("<% weekEnd %>");
const dailyPath = "10_Operations/09_Journals/01_Daily";

const counts = {};
for (const tag of tagList) {
  counts[tag] = 0;
}

const pages = dv
  .pages(`"${dailyPath}"`)
  .where((p) => p.file?.day >= start && p.file?.day <= end);

for (const page of pages) {
  const content = await dv.io.load(page.file.path);
  const lines = content.split("\n");
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line.includes("#")) continue;
    const matches = line.match(tagRegex) ?? [];
    for (const tag of matches) {
      if (tagSet.has(tag)) {
        counts[tag] += 1;
      }
    }
  }
}

const rows = tagList.map((tag) => [tag, counts[tag]]);
dv.table(["Tag", "Count"], rows);
```

---
## RSS Watchlist Keyword Frequency (Week)
```dataviewjs
const NEWS_FOLDERS = [
  "20_Intelligence/21_News",
  "00_System/99_Inbox/_staging/21_News"
];
const WATCHLIST_FOLDERS = [
  "10_Operations/13_Watchlists",
  "30_CIPHER/05_Watchlists"
];

const norm = (v) => (v ?? "").toString().trim().toLowerCase();
const arr = (v) => Array.isArray(v) ? v : (v ? [v] : []);

const start = dv.date("<% weekStart %>");
const end = dv.date("<% weekEnd %>");

const watchPages = [];
for (const f of WATCHLIST_FOLDERS) {
  watchPages.push(...dv.pages(`"${f}"`).array());
}

const terms = new Set();
for (const p of watchPages) {
  for (const entry of arr(p.keywords)) {
    if (typeof entry === "string") {
      const t = norm(entry);
      if (t) terms.add(t);
    } else if (entry && typeof entry === "object") {
      const t = norm(entry.term ?? entry.keyword ?? entry.value);
      if (t) terms.add(t);
    }
  }
}

if (terms.size === 0) {
  dv.paragraph("No watchlist keywords found.");
  return;
}

const newsPages = [];
for (const f of NEWS_FOLDERS) {
  newsPages.push(...dv.pages(`"${f}"`).array());
}

const filtered = newsPages.filter((p) => {
  const d = dv.date(p.published ?? p.file?.day ?? p.file?.ctime);
  return d && d >= start && d <= end;
});

if (filtered.length === 0) {
  dv.paragraph("No RSS items in the selected date range.");
  return;
}

const counts = new Map();
for (const t of terms) counts.set(t, 0);

for (const p of filtered) {
  const content = await dv.io.load(p.file.path);
  const blob = norm(`${p.title ?? p.file.name}\n${content}`);
  for (const t of terms) {
    if (blob.includes(t)) {
      counts.set(t, (counts.get(t) || 0) + 1);
    }
  }
}

const rows = Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);
const top = rows.slice(0, 15);
const bottom = rows.slice(-15).reverse();

dv.table(["Top Keywords", "Count"], top);
dv.table(["Bottom Keywords", "Count"], bottom);
```

---
## Wheel of Life

- **Soul:** `INPUT[slider(minValue(1), maxValue(10)):weekly_soul_score]`
- **Career/Work:**`INPUT[slider(minValue(1), maxValue(10)):weekly_career_score]`
- **Love/Relationships:**`INPUT[slider(minValue(1), maxValue(10)):weekly_relationships_score]`
- **Health/Fitness:**`INPUT[slider(minValue(1), maxValue(10)):weekly_health_score]`
- **Personal Growth:**`INPUT[slider(minValue(1), maxValue(10)):weekly_personal_growth_score]`
- **Fun/Recreation:**`INPUT[slider(minValue(1), maxValue(10)):weekly_fun_score]`
- **Social:**`INPUT[slider(minValue(1), maxValue(10)):weekly_social_score]`
- **Finances:**`INPUT[slider(minValue(1), maxValue(10)):weekly_finance_score]`
- **Energy:**`INPUT[slider(minValue(1), maxValue(10)):weekly_energy_score]`
- **Cynicism:**`INPUT[slider(minValue(1), maxValue(10)):weekly_cynicism_score]`
- **Productivity:**`INPUT[slider(minValue(1), maxValue(10)):weekly_productivity_score]`

```dataviewjs

const chartData = {
	type: 'polarArea',
	data: {
		labels: ['Soul', 'Career/Work', 'Love/Relationships', 'Health/Fitness', 'Personal Growth', 'Fun/Recreation', 'Social', 'Finances', 'Energy', 'Cynicism', 'Productivity'],
		datasets: [{
			data: [
				dv.current().weekly_soul_score,
				dv.current().weekly_career_score,
				dv.current().weekly_relationships_score,
				dv.current().weekly_health_score,
				dv.current().weekly_personal_growth_score,
				dv.current().weekly_fun_score,
				dv.current().weekly_social_score,
				dv.current().weekly_finance_score,
				dv.current().weekly_energy_score,
				dv.current().weekly_cynicism_score,
				dv.current().weekly_productivity_score,
			],
			backgroundColor: [
				'rgba(220,20,60,0.4)',
				'rgba(0,128,128,0.4)',
				'rgba(255,140,0,0.4)',
				'rgba(0,127,255,0.4)',
				'rgba(255,215,0,0.4)',
				'rgba(102,51,153,0.4)',
				'rgba(127,255,0,0.4)',
				'rgba(255,0,127,0.4)',
				'rgba(135,206,235,0.4)',
				'rgba(255,127,80,0.4)',
				'rgba(75,0,130,0.4)'
			],
			borderColor: [
				'rgba(220,20,60,1.0)',
				'rgba(0,128,128,1.0)',
				'rgba(255,140,0,1.0)',
				'rgba(0,127,255,1.0)',
				'rgba(255,215,0,1.0)',
				'rgba(102,51,153,1.0)',
				'rgba(127,255,0,1.0)',
				'rgba(255,0,127,1.0)',
				'rgba(135,206,235,1.0)',
				'rgba(255,127,80,1.0)',
				'rgba(75,0,130,1.0)'
			],
			borderWidth: 2
		}]
	},
	options: {
		plugins: {
			legend: {
				position: 'bottom',
				labels: {
					color: '#fff',
				}
				
			}
		},
		scales: {
			r: {
				angleLine: {
					display: true,
					color: "rgba(200,200,200,0.5)"
				},
				grid: {
					color: "rgba(150,150,150,0.3)",
					lineWidth: 1
				},
				ticks: {
					display: true,
					stepSize: 1,
					color: "white",
					font: {
						size: 12,
						family: "'Inter', sans-serif"						
					},
					backdropColor: "transparent"
				},
				min: 1,
				max: 10
			}
		}
	}
	
}


const container = this.container;
container.style.height = '700px';
container.style.padding = '20px';
container.style.overflow = 'hidden';



window.renderChart(chartData, container);
```


- [.] **Soul**: 5 #log/weekly_soul
	- Meditation, prayer, yoga, reading spiritual texts, attending religious services, spending time in nature, practicing gratitude.

- [.] **Career/Work**: 5 #log/weekly_career
	- Achieving career milestones, acquiring new skills, job performance, work-life balance, networking, and professional development.

- [.] **Love/Relationships**: 5 #log/weekly_relationships
	- Spending quality time with a partner, open communication, romantic gestures, resolving conflicts, and shared activities.

- [.] **Health/Fitness** : 5 #log/weekly_health
	- Regular exercise, balanced diet, routine health check-ups, adequate sleep, and stress management.

- [.] **Personal Growth** : 5 #log/weekly_personal_growth
	- Reading, taking courses, learning new skills, setting personal goals, practicing mindfulness, and self-reflection.

- [.] **Fun/Recreation** : 5 #log/weekly_fun
	- Playing sports, traveling, engaging in hobbies, watching movies, playing games, and any activities that you find enjoyable and relaxing.

- [.] **Social** : 5 #log/weekly_social
	- Socializing with friends, attending social events, participating in community activities, joining clubs or groups, and volunteering

- [.] **Finance** : 5 #log/weekly_finance
	- Budgeting, saving, investing, managing expenses, financial planning, and debt management.

- [.] **Energy** : 5 #log/weekly_energy
	- Tracking energy levels throughout the day, identifying energy boosters and drainers, managin caffeine intake, creating restorative routines, taking regular breaks, and developing sustainable daily habits.

- [.] **Cynicism** : 5 #log/weekly_cynicism
	- Recognizing negative thought patterns, challenging assumptions, reframing perspectives, practicing empathy, engaging in positive interactions, and observing how cynicism influences mood, choices, and relationships.

- [.] **Productivity** : 5 #log/weekly_productivity
	- Prioritizing tasks, reducing distractions, using organizational systems, time blocking, achieving goals efficiently, reviewing progress, and refining workflows to improve output and focus.


## Statistics
### Burnout Heatmaps

```dataviewjs
// Folder where your daily notes live
const PATH_TO_YOUR_FOLDER = "10_Operations/09_Journals/01_Daily";

// All the metrics you want to track (YAML keys)
const METRICS = [
  {
    key: "energy_rating",
    title: "Energy",
    subtitle: "Daily energy rating (0–10)"
  },
  {
    key: "cynicism_rating",
    title: "Cynicism",
    subtitle: "Daily cynicism rating (0–10)"
  },
  {
    key: "productivity_rating",
    title: "Productivity",
    subtitle: "Daily productivity rating (0–10)"
  }
];

if (typeof renderHeatmapTracker !== "function") {
  dv.paragraph("Heatmap tracker is unavailable. Enable the Heatmap Tracker plugin to render this section.");
} else {
  // Loop over each metric and render a separate heatmap
  for (const metric of METRICS) {
    const trackerData = {
      entries: [],
      separateMonths: true,
      heatmapTitle: metric.title,
      heatmapSubtitle: metric.subtitle,
      // 0–10 rating scale
      intensityScaleStart: 0,
      intensityScaleEnd: 10,
      // Your custom color scheme
      colorScheme: {
        paletteName: "default", // you can also reference a palette defined in plugin settings
        customColors: ["#44ce1b", "#bbdb44", "#f7e379", "#f2a134", "#e51f1f"]
      }
    };

    // Collect pages in your Daily folder that actually have this key
    for (let page of dv.pages(`"${PATH_TO_YOUR_FOLDER}"`).where(p => p[metric.key] != null)) {
      trackerData.entries.push({
        // Assumes file name is YYYY-MM-DD
        date: String(page.file.name).slice(0, 10),
        filePath: page.file.path,
        intensity: Number(page[metric.key])
      });
    }

    // Optional: used when clicking on empty days to create a note there
    trackerData.basePath = PATH_TO_YOUR_FOLDER;

    // Core Heatmap Tracker API call
    renderHeatmapTracker(this.container, trackerData);
  }
}
```




# Weekly Rollup — Week of {{week_of}}

## 1. Executive Summary
Provide a high-level summary of the week:
- Major themes  
- High-impact incidents  
- Emerging risks  
- Operational trends  
- Noteworthy wins or concerns  

Write this section as if it may be forwarded to senior leadership.

---

## 2. Incident & Investigation Overview
### 2.1 New Incidents
- INC-#### — Summary
- INC-#### — Summary

### 2.2 Closed Incidents
- INC-#### — Resolution summary

### 2.3 Notable Investigations
Highlight investigations with interesting findings, complex analysis, or cross-team involvement.

---

## 3. Alert & Detection Activity
Summarize the week’s alert workload:
- Total alerts reviewed  
- Percent true positives vs false positives  
- Detection gaps identified  
- Noisy or misfiring analytic rules  
- Improvements made  

### 3.1 Detection Engineering Notes
- New detections deployed  
- Tuning performed  
- Telemetry gaps discovered  
- Proposed detection improvements  

---

## 4. TTP & Threat Activity Summary
### 4.1 Notable MITRE Techniques Observed
- TXXXX — brief summary of usage
- TYYYY — brief summary of usage


### 4.2 Threat Actor or Campaign Activity
Document any activity or intel notes relevant to SOC operations:
- Emergent threats  
- Ongoing campaigns  
- Industry-aligned attacks  
- Internal risk insights  

### 4.3 IOC Patterns & Clusters
Summarize meaningful IOC observations:
- IP clusters  
- Domain patterns  
- Hash repetition  
- Infrastructure overlap  

These should link to relevant IOC entities.

---

## 5. Response Actions Summary
Summarize major actions taken:
- Host isolations  
- Account disables  
- Password resets  
- Firewall blocks  
- Cloud containment operations  

Highlight:
- Any operational burden  
- Any issues or delays  
- Any approval bottlenecks  

---

## 6. Projects, Improvements & Engineering Work
Document work outside incidents/alerts:
- Detection modernization  
- Logging improvements  
- Playbook or SOP updates  
- Tool integrations  
- Threat hunting initiatives  
- Automation or SOAR development  
- Reporting or dashboard upgrades  

This is where the SOC shows progress beyond simply responding to tickets.

---

## 7. Team & Shift Health
Optional but valuable:
- Workload distribution  
- Coverage challenges  
- Overtime or on-call impacts  
- Burnout risks  
- Training completed  
- Kudos to team members  

This helps leadership manage people, not just incidents.

---

## 8. Key Risks, Issues & Dependencies
Document forward-looking risks:
- Tool outages  
- Visibility gaps  
- Staffing challenges  
- Notification failures  
- Process misalignments  
- Environmental vulnerabilities  

And call out dependencies (e.g., engineering teams, IAM, cloud ops) that influence SOC success.

---

## 9. Next Week’s Focus
Summarize:
- Planned initiatives  
- Key investigations to watch  
- Projects continuing into next week  
- Maintenance or operational deadlines  
- Training or tabletop exercises  

---

## 10. Attachments / Linked Entities
Link to:
- Incidents  
- Investigations  
- Playbooks used  
- Response Actions  
- Observations  
- Dashboards  
- Reports  

This enables interactive navigation through the SCOUT knowledge graph.
> [!capacities-prop]
> Contents
