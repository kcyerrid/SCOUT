---
entity_type: daily_journal
aliases:
analyst: ""
shift_type: ""
shift_start: ""
shift_end: ""
focus_areas: []
energy_rating:
cynicism_rating:
productivity_rating:
music_selection: []
picture_of_the_day: ""
open_tasks: []
planned_tasks: []
related_alerts: []
related_incidents: []
related_investigations: []
related_observations: []
related_response_actions: []
related_projects: []
tags:
created:
updated:
banner: 99_Attachments/SCOUT_Obsidian_Banner.png
banner-display: contain
banner-repeat: false
banner-height: 100
content-start: 101
journal: Journal Daily
journal_date:
---

```calendar-nav

```
# Daily Journal —  {{created}}

---

## Picture of the day for  

!{{picture_of_the_day}}




---

## Morning Pages
> [!journal]- On This Day...
> ```dataview
> LIST
> FROM "10_Operations/09_Journals/01_Daily"
> WHERE dateformat(file.day,"MM-dd") = dateformat(this.file.day, "MM-dd")
> ```

> [!calendar]- Notes Created This Day
> ```dataview
> TABLE created, updated as modified, tags, summary
> FROM "" AND !"Journal" AND !"Templates"
> WHERE icontains(dateformat(file.ctime, "YYYY-MM-DD"), dateformat(this.file.day,"YYYY-MM-DD"))
> ```

> [!task]- Tasks
> ```dataview
> TASK
> WHERE !completed
> AND icontains(text,"[[2024-08-")
> AND icontains(text, "#task")
> GROUP BY file.name as filename
> SORT rows.file.ctime DESC
> ```

---
## 1. Overview
Summarize your focus for the day:
- Major priorities  
- High-level context  
- Expected workload  
- Any known risks or escalations  

Example:
> “Focus on identity anomaly triage and follow-up on incident INC-2025-0021. Begin tuning project for CloudApp anomalous token usage.”

---

## 2. Shift Notes (Chronological Log)
This is the core of the journal — a running log of your day.

<!-- Status/milestone tag taxonomy:
- #report/weekly (include in weekly status rollup)
- #milestone/accomplishment
- #milestone/incident
- #milestone/impact
-->
**Milestone/Status Tags (inline):**
- Add tags on the same line as the log entry to flag rollups.
- Examples: `#report/weekly`, `#milestone/accomplishment`, `#milestone/incident`, `#milestone/impact`

**Quick Log Command (Templater):**
- Use the template `Log To Daily Shift Notes` to append the current note to today’s Shift Notes.

**For each entity type created using the Scout Launcher, an entry will be added to this log.  Configure the template for each entity type in the Shift Log Rules option on the SCOUT Launcher.**

<!-- SHIFT_NOTES_LOG -->

This provides a **forensic-quality record** of your day.

---

## 3. Key Findings of the Day
Highlight your top insights:
- Confirmed malicious activity  
- Detection tuning opportunities  
- Visibility issues discovered  
- Process gaps  
- Identity or behavioral anomalies  
- Any suspected threat actor alignment  

Use bullets for clarity.

---

## 4. Observations Logged Today
Link to formal Observation entries created during this shift.

### Observations
```dataviewjs
const obsDay = dv.current().file.day ?? dv.date(dv.current().journal_date);
const obsDayKey = obsDay ? dv.date(obsDay)?.toFormat("yyyy-LL-dd") : null;
const observationPages = dv
  .pages()
  .where((page) => page.entity_type === "observation")
  .where((page) => {
    const updated = page.updated ?? page.created ?? page.file?.mtime;
    if (!updated || !obsDayKey) return false;
    const updatedDate = dv.date(updated);
    if (!updatedDate) return false;
    return updatedDate.toFormat("yyyy-LL-dd") === obsDayKey;
  })
  .sort((page) => page.updated ?? page.created ?? page.file?.mtime, "desc");

if (observationPages.length === 0) {
  dv.paragraph("No observations logged for this day.");
} else {
  dv.table(
    ["Observation", "Relevance", "Updated"],
    observationPages.map((page) => [
      page.file.link,
      page.relevance ?? "",
      page.updated ?? ""
    ])
  );
}
```
This reinforces the use of atomic notes.

---

## 5. Response Actions Performed Today
Link to Response Action entries.

### Response Actions
```dataviewjs
const raDay = dv.current().file.day ?? dv.date(dv.current().journal_date);
const raDayKey = raDay ? dv.date(raDay)?.toFormat("yyyy-LL-dd") : null;
const responsePages = dv
  .pages()
  .where((page) => page.entity_type === "response_action")
  .where((page) => {
    const updated = page.updated ?? page.created ?? page.file?.mtime;
    if (!updated || !raDayKey) return false;
    const updatedDate = dv.date(updated);
    if (!updatedDate) return false;
    return updatedDate.toFormat("yyyy-LL-dd") === raDayKey;
  })
  .sort((page) => page.updated ?? page.created ?? page.file?.mtime, "desc");

if (responsePages.length === 0) {
  dv.paragraph("No response actions logged for this day.");
} else {
  dv.table(
    ["Response Action", "Status", "Priority", "Updated"],
    responsePages.map((page) => [
      page.file.link,
      page.action_status ?? page.status ?? "",
      page.action_priority ?? page.priority ?? "",
      page.updated ?? ""
    ])
  );
}
```

This helps quantify SOC workload.

---

## 6. Incidents & Investigations Worked
Link every incident or investigation touched today.

### Incidents
```dataviewjs
const day = dv.current().file.day ?? dv.date(dv.current().journal_date);
const dayKey = day ? dv.date(day)?.toFormat("yyyy-LL-dd") : null;
const incidentPages = dv
  .pages()
  .where((page) => page.entity_type === "incident")
  .where((page) => {
    const updated = page.updated ?? page.created ?? page.file?.mtime;
    if (!updated || !dayKey) return false;
    const updatedDate = dv.date(updated);
    if (!updatedDate) return false;
    return updatedDate.toFormat("yyyy-LL-dd") === dayKey;
  })
  .sort((page) => page.updated ?? page.created ?? page.file?.mtime, "desc");

if (incidentPages.length === 0) {
  dv.paragraph("No incidents logged for this day.");
} else {
  dv.table(
    ["Incident", "Status", "Severity", "Updated"],
    incidentPages.map((page) => [
      page.file.link,
      page.status ?? "",
      page.severity ?? "",
      page.updated ?? ""
    ])
  );
}
```

### Investigations
```dataviewjs
const invDay = dv.current().file.day ?? dv.date(dv.current().journal_date);
const invDayKey = invDay ? dv.date(invDay)?.toFormat("yyyy-LL-dd") : null;
const investigationPages = dv
  .pages()
  .where((page) => page.entity_type === "investigation")
  .where((page) => {
    const updated = page.updated ?? page.created ?? page.file?.mtime;
    if (!updated || !invDayKey) return false;
    const updatedDate = dv.date(updated);
    if (!updatedDate) return false;
    return updatedDate.toFormat("yyyy-LL-dd") === invDayKey;
  })
  .sort((page) => page.updated ?? page.created ?? page.file?.mtime, "desc");

if (investigationPages.length === 0) {
  dv.paragraph("No investigations logged for this day.");
} else {
  dv.table(
    ["Investigation", "Status", "Priority", "Updated"],
    investigationPages.map((page) => [
      page.file.link,
      page.status ?? "",
      page.priority ?? "",
      page.updated ?? ""
    ])
  );
}
```

---

## 7. Cross-Functional Interactions
Document interactions with:
- IT  
- Engineering  
- Cloud  
- HR  
- Legal  
- Product teams  
- Leadership  

Capture:
- Requests made  
- Information exchanged  
- Decisions reached  

This helps reconstruct decision pathways.

---

## 8. Training, Research & Development
Record any time spent on:
- Labs  
- Training modules  
- Threat intel reading  
- Internal documentation improvements  
- Detection engineering prototypes  
- Experimentation  
- Hunt hypothesis ideation  

This supports career development tracking.

---

## 9. Roadblocks & Issues
Document any blockers:
- Missing permissions  
- Gaps in logs  
- Tool outages  
- Delayed responses from teams  
- Unexpected behavior in SOC tooling  

Assign follow-up tasks if needed.

---

## 10. Tasks Completed
Summarize work achieved today:
- Alerts closed  
- Incidents advanced  
- Investigations progressed  
- SOPs updated  
- Playbook refinements  
- Documentation improvements  

This supports analyst scorecards and weekly rollups.

---

## 11. RSS Watchlist Keyword Frequency (Today)
```dataviewjs
const NEWS_FOLDERS = [
  "20_Intelligence/21_News",
  "00_System/99_Inbox/_staging/21_News"
];
const WATCHLIST_FOLDERS = [
  "10_Operations/13_Watchlists",
  "30_CIPHER/05_Watchlists"
];

const norm = (v) => (v ?? "").toString().trim().toLowerCase();
const arr = (v) => Array.isArray(v) ? v : (v ? [v] : []);

const day = dv.current().file.day ?? dv.date(dv.current().journal_date);
if (!day) {
  dv.paragraph("No journal date found.");
  return;
}
const start = day.startOf("day");
const end = day.endOf("day");

const watchPages = [];
for (const f of WATCHLIST_FOLDERS) {
  watchPages.push(...dv.pages(`"${f}"`).array());
}

const terms = new Set();
for (const p of watchPages) {
  for (const entry of arr(p.keywords)) {
    if (typeof entry === "string") {
      const t = norm(entry);
      if (t) terms.add(t);
    } else if (entry && typeof entry === "object") {
      const t = norm(entry.term ?? entry.keyword ?? entry.value);
      if (t) terms.add(t);
    }
  }
}

if (terms.size === 0) {
  dv.paragraph("No watchlist keywords found.");
  return;
}

const newsPages = [];
for (const f of NEWS_FOLDERS) {
  newsPages.push(...dv.pages(`"${f}"`).array());
}

const filtered = newsPages.filter((p) => {
  const d = dv.date(p.published ?? p.file?.day ?? p.file?.ctime);
  return d && d >= start && d <= end;
});

if (filtered.length === 0) {
  dv.paragraph("No RSS items in the selected date range.");
  return;
}

const counts = new Map();
for (const t of terms) counts.set(t, 0);

for (const p of filtered) {
  const content = await dv.io.load(p.file.path);
  const blob = norm(`${p.title ?? p.file.name}\n${content}`);
  for (const t of terms) {
    if (blob.includes(t)) {
      counts.set(t, (counts.get(t) || 0) + 1);
    }
  }
}

const rows = Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);
const top = rows.slice(0, 10);
const bottom = rows.slice(-10).reverse();

dv.table(["Top Keywords", "Count"], top);
dv.table(["Bottom Keywords", "Count"], bottom);
```

---

## 12. Tasks to Carry Forward
List tasks that remain outstanding:

```tasks
not done
due after yesterday
```


---

## 13. End-of-Shift Summary
Provide a final closing note:
- Major outcomes  
- Remaining risks  
- Items requiring next-shift awareness  
- Any escalation requirements  

Example:
> “Monitoring required overnight for suspicious token activity on user rsmith. Incident INC-2025-0021 fully contained. No active high-severity investigations.”


