---
entity_type: incident
incident_id: INC-2026-000004
title: Test Incident for Weekly Rollup
incident_type: ""
incident_subtype: ""
severity: low
priority:
status: new
created_time: 2026-01-29 00:15:31
detected_time: 2026-01-29 00:15:31
reported_time: ""
triage_start_time: ""
triage_end_time: ""
containment_time: ""
eradication_time: ""
recovery_time: ""
closed_time: ""
mttd: ""
mttr: ""
alert_sources: ticket
root_cause: ""
impact_summary: ""
primary_asset: ""
primary_user: YOUR NAME
affected_assets: ""
affected_users: []
related_iocs: []
related_ttp: []
related_detections: []
related_tools: []
related_malware: []
related_campaigns: []
related_actors: []
response_actions: []
observations: []
escalation_required: false
escalated_to: ""
regulatory_reporting_required: false
regulatory_deadline: ""
regulatory_status: ""
business_owner_notified: false
executive_notification_required: false
lessons_learned_status:
tags:
banner: 99_Attachments/SCOUT_Obsidian_Banner.png
banner-display: contain
banner-repeat: false
banner-height: 100
content-start: 101
created: 2026-01-29 00:15:31
updated: 2026-01-29 00:15:51
tlp_classification: TLP:GREEN
---
<%*
const DAILY_ROOT = "10_Operations/09_Journals/01_Daily";
const MARKER = "<!-- SHIFT_NOTES_LOG -->";
const SHIFT_HEADING = "## 2. Shift Notes (Chronological Log)";

const today = tp.date.now("YYYY-MM-DD");
const dailyFile = tp.file.find_tfile(today);
if (!dailyFile) {
  new Notice("Daily note not found for " + today);
  return;
}

const incidentId = (tp.frontmatter?.incident_id || "").toString().trim();
const incidentTitle = (tp.frontmatter?.title || "").toString().trim() || tp.file.title;
const timeStamp = tp.date.now("HH:mm");
const headerTitle = [incidentId, incidentTitle].filter(Boolean).join(" - ");
const headerLine = `### ${timeStamp} — ${headerTitle}`;

const block = [
  headerLine,
  "",
  "Context:",
  "",
  "- What triggered this work?",
  "- Why did you look into it?",
  "",
  "Actions:",
  "",
  "- What did you do?",
  "- Queries executed?",
  "- Tools used?",
  "",
  "Findings:",
  "",
  "- What did you learn?",
  "- Any anomalies or notable patterns?",
  "",
  "Links:",
  "- [Alert link]",
  "- [Incident link]",
  "- [Investigation link]",
  "- [Observation link]",
  ""
].join("\n");

const content = await app.vault.read(dailyFile);
let updated = content;

if (content.includes(MARKER)) {
  const markerIdx = content.indexOf(MARKER);
  const sectionStart = markerIdx + MARKER.length;
  let nextHeadingIdx = content.indexOf("\n## ", sectionStart);
  if (nextHeadingIdx === -1) nextHeadingIdx = content.length;
  const sectionBody = content.slice(sectionStart, nextHeadingIdx).replace(/\n+$/g, "");
  const insert = sectionBody.trim() ? `${sectionBody}\n${block}\n` : `\n${block}\n`;
  updated = content.slice(0, sectionStart) + insert + content.slice(nextHeadingIdx);
} else if (content.includes(SHIFT_HEADING)) {
  const idx = content.indexOf(SHIFT_HEADING);
  let nextHeadingIdx = content.indexOf("\n## ", idx + SHIFT_HEADING.length);
  if (nextHeadingIdx === -1) nextHeadingIdx = content.length;
  const sectionBody = content.slice(idx + SHIFT_HEADING.length, nextHeadingIdx).replace(/\n+$/g, "");
  const insert = sectionBody.trim() ? `${sectionBody}\n${block}\n` : `\n${block}\n`;
  updated = content.slice(0, idx + SHIFT_HEADING.length) + insert + content.slice(nextHeadingIdx);
} else {
  updated = content + `\n\n${block}\n`;
}

await app.vault.modify(dailyFile, updated);
%>
# Incident: Test Incident for Weekly Rollup

## 1. Executive Summary
Provide a concise overview of:
- What happened
- What triggered detection
- What systems or identities were affected
- What actions were taken
- Current status
- Business impact

This summary is leadership-facing.

---

## 2. Incident Timeline Overview
Summarize key timestamps:
- Detection
- Reporting
- Triage
- Containment
- Eradication
- Recovery
- Closure

Highlight major delays or accelerations.

---

## 3. Initial Detection & Triage
### 3.1 Detection Path
Explain:
- Where the detection came from (alert, observation, hunt, third-party report)
- Which tools or logs contributed to discovery

### 3.2 Initial Triage Summary
Include:
- Hypotheses formed during triage
- Indicators that elevated the event to an incident
- Key findings from early analysis

---

## 4. Technical Analysis
Describe what was actually happening under the hood.  
Organize by relevant ATT&CK TTPs, behaviors, or stages of the kill chain.

Include:
- Attack vector  
- Privilege usage  
- Lateral movement evidence  
- Persistence mechanisms  
- Data access or exfiltration  
- Misconfigurations exploited  
- Malware or tools involved  

This is the core analytical narrative.

---

## 5. Scope & Impact Assessment
Document:
- Assets affected  
- Users impacted  
- Systems or data at risk  
- Business function disruption  
- Estimated severity and potential consequences  

If impact is unknown, describe what is being done to determine it.

---

## 6. Containment, Eradication & Recovery
### 6.1 Containment Actions
Summarize steps, linked to Response Action pages.

### 6.2 Eradication
Document what was removed or corrected.

### 6.3 Recovery
Describe:
- What systems were restored
- Business steps taken
- Verification actions performed  
- Risk of recurrence

---

## 7. Linked Entities
### 7.1 Alerts
- link

### 7.2 Observations
- link

### 7.3 Response Actions
- link

### 7.4 Assets / Users
- link

### 7.5 IOCs
- link

### 7.6 MITRE TTPs
- link

### 7.7 Malware / Tools
- link

### 7.8 Threat Actors / Campaigns
- link

---

## 8. Root Cause Analysis
Explain:
- The primary cause of the incident  
- Contributing factors  
- Environmental weaknesses exploited  
- How similar incidents could be prevented

This should be actionable and precise.

---

## 9. Lessons Learned
Document:
- What went well  
- What needs improvement  
- Process gaps  
- Detection blind spots  
- Operational inefficiencies  
- Communication issues  

Assign owners for corrective actions if applicable.

---

## 10. Recommendations
Provide actionable recommendations for:
- Detection engineering  
- Infrastructure/security hardening  
- IAM improvements  
- Tooling or visibility gaps  
- Playbook or SOP updates  
- Training needed for analysts

Prioritize clearly.

---

## 11. Final Status & Closure
Summarize:
- Current state of systems
- Any residual risk
- Outstanding tasks
- Confirmation that the business is fully restored

Mark the incident as closed when appropriate.


